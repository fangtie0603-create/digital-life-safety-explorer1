# DEPLOY.md｜數位生活安全探險隊部署指南

本專案是無建置工具的純靜態網站。請將 `index.html`、`style.css`、`sketch.js`、`README.md`、`DESIGN.md` 與本檔案放在同一個專案根目錄；不要改變相對路徑。

> 重要提醒：本次只能產出可上傳的網站檔案，不能假稱已自動產生永久公開網址。工具沒有使用者的 GitHub、Netlify 或 Vercel 帳號權限；真正的公開網址會在使用者上傳並完成發布後，由託管平台產生。

## 1. GitHub Pages

1. 登入 GitHub，建立一個 repository（可選公開或私有，依帳號方案而定）。
2. 將本資料夾內的檔案上傳到 repository 根目錄，確認 `index.html` 位於根目錄。
3. 開啟 repository 的 **Settings → Pages**。
4. 在 **Build and deployment** 選 **Deploy from a branch**，選擇 `main` 分支與 `/ (root)`，按 **Save**。
5. 等待 GitHub Actions／Pages 完成部署，再依 Pages 頁面顯示的網址開啟網站。

GitHub Pages 不需要執行 npm 或其他建置指令；本專案的 p5.js 由 `index.html` 載入 CDN。

## 2. Netlify Drop

1. 開啟 <https://app.netlify.com/drop> 並登入 Netlify。
2. 將整個專案資料夾（不是只選單一檔案）拖曳到 Drop 區域。
3. 等待上傳完成，Netlify 會在畫面上提供一個預覽網址。
4. 若要長期使用，可在 Netlify 專案設定中自訂 site name 或連接自己的網域。

## 3. Vercel

### 使用 Dashboard

1. 登入 <https://vercel.com/>。
2. 選 **Add New → Project**，連接存放專案的 Git repository。
3. Framework Preset 選 **Other** 或 **No Framework**。
4. Build Command 留空；Output Directory 使用根目錄（通常不需填寫）。
5. 按 **Deploy**，完成後使用 Vercel 顯示的網址。

### 使用 Vercel CLI（可選）

在專案資料夾執行：

```bash
npx vercel
```

依提示登入並部署。這不是本專案必要步驟，Dashboard 或 Git 整合也可以完成發布。

## 4. 本機測試

在專案資料夾執行：

```bash
python3 -m http.server 8000
```

接著用瀏覽器開啟 <http://localhost:8000>。停止伺服器可在終端機按 `Ctrl+C`。

## 部署前檢查清單

- [ ] `index.html` 位於部署根目錄。
- [ ] `style.css` 與 `sketch.js` 和 `index.html` 同層。
- [ ] 使用可連線網路，因為 p5.js 由 jsDelivr CDN 載入。
- [ ] 沒有把 ZIP 的外層資料夾再多包一層後才上傳。
- [ ] 用手機或平板實際點擊開始、答題、錯題再練與重新開始。
- [ ] 確認瀏覽器允許在使用者按鈕互動後播放程式合成音效。
