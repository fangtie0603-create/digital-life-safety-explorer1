# 數位生活安全探險隊

這是一個「原創改編」的 p5.js 多媒體教學遊戲，對象是國小中高年級。玩家會在 8 個日常數位情境中判斷下一步，學習辨識可疑訊息、建立安全密碼、保護個人資料與展現網路禮儀。

> 本專案重新設計主題、題目、插圖、色彩、版面和文字，不使用外部圖片、音效或未授權素材。

## 專案結構

```text
digital-life-safety-explorer/
├── index.html   # 網站入口、metadata、p5.js CDN 與三個遊戲畫面
├── style.css    # 深藍夜空／螢光青綠／橘色警示的響應式介面
├── sketch.js    # 題庫、遊戲邏輯、DOM 互動、p5.js 幾何插圖、Web Audio
├── README.md    # 專案說明與使用方式
├── DESIGN.md    # 教學目標、介面設計與測試規劃
└── DEPLOY.md    # GitHub Pages、Netlify、Vercel 與本機部署步驟
```

本專案是無建置工具的純靜態網站。`index.html`、`style.css`、`sketch.js`、`README.md`、`DESIGN.md` 與 `DEPLOY.md` 放在同一層即可部署。p5.js 使用固定版本 CDN；所有圖像由 p5.js 幾何繪製，提示音由使用者互動後啟用的 Web Audio API 程式合成。

## 公開部署

最短步驟請看 [DEPLOY.md](DEPLOY.md)。可以將整個專案資料夾直接上傳至 GitHub Pages、Netlify 或 Vercel，不需要 npm、編譯器或建置指令。

請注意：本專案只提供可上傳的網站檔案與部署說明，無法代替使用者登入託管平台，也不會在未取得帳號權限的情況下產生永久公開網址。真正的網站網址會由使用者完成上傳與發布後，由所選平台提供。

## 如何在 p5.js Web Editor 使用

1. 開啟 [p5.js Web Editor](https://editor.p5js.org/) 並建立新專案。
2. 將 `index.html` 的內容貼到 Web Editor 的 `index.html`。
3. 新增或替換 `style.css`，貼上本專案的 CSS。
4. 新增或替換 `sketch.js`，貼上本專案的程式。
5. 按播放；第一次按「開始探險」後才會初始化音效，符合瀏覽器禁止自動播放的規則。
6. Web Editor 若已有 `libraries` 資料夾可以不使用；本專案直接在 `index.html` 載入 p5.js CDN。

## 如何在本機開啟

建議在專案資料夾執行：

```bash
python3 -m http.server 8000
```

再開啟 <http://localhost:8000>。也可以直接雙擊 `index.html`；如果瀏覽器限制本機檔案功能，請改用簡易伺服器。

## 遊戲規則

- 首頁按「開始探險」後，依序完成 8 題，每次顯示一題。
- 每題有 3 個選項，選完會立即標示正確答案，並顯示回饋、解說與下一題按鈕。
- 每答對一題得到 1 格分數；結果頁分數換算為百分比。
- 結果頁依四個學習目標顯示 `答對數 / 題目數` 與長條圖。
- 按「錯題再練」只會重新出現這一輪答錯的題目；若全答對，會顯示鼓勵訊息。
- 「提示音開／關」只影響程式合成的回饋音，音效會在使用者按下開始或音效按鈕後才建立 AudioContext。

## 題庫與程式重點

題庫位於 `sketch.js` 開頭的 `QUESTIONS` 陣列。每題包含 `id`、`goal`、`visual`、`hint`、`prompt`、`options`、`answer` 與 `explain`。主要函式包括：

- `setup()`：建立 p5 canvas、綁定 HTML 按鈕。
- `draw()`：依 `appState` 繪製首頁、題目或結果插圖。
- `windowResized()`：使用 debounce 延遲調整目前 canvas 的尺寸。
- `chooseAnswer()`：判斷答案、更新選項顏色、紀錄分數並播放提示音。
- `startRetry()`：從作答紀錄取出錯題索引，建立新的練習佇列。
- `renderGoalStats()`：依四項技能產生結果統計。

程式使用安全的 DOM 查找與事件綁定；即使部分非核心元素不存在，也會跳過該操作而不讓整個遊戲因單一 DOM 元素中斷。所有操作按鈕都是語意化 HTML `button`，方便鍵盤操作與輔助工具使用。

## 原創性與素材說明

- 8 題情境、錯誤選項、解釋文字皆為本專案重新撰寫。
- 訊息卡、鎖頭、盾牌、警示符號、對話泡泡和星空動畫皆由 p5.js 幾何圖形繪製。
- 回饋音由 Web Audio API 的 oscillator 與 gain 節點合成，不使用外部音檔。
- p5.js CDN：<https://cdn.jsdelivr.net/npm/p5@1.11.1/lib/p5.min.js>。

## 測試建議

- 逐題測試答對、答錯、最後一題、錯題再練和全答對情況。
- 在桌機、平板與手機寬度確認題目卡、選項換行和按鈕可點擊。
- 關閉提示音後作答，確認不再播放音效；重新整理後按開始，確認沒有自動播放錯誤。
- 使用鍵盤 Tab 移動焦點，確認主要按鈕有清楚的 focus 樣式。
